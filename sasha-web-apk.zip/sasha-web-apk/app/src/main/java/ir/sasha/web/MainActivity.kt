package ir.sasha.web

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.webkit.CookieManager
import android.webkit.JsResult
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen

/** آدرس وب‌اپ ساشا؛ اگه سایت جای دیگه‌ای بود فقط همین خط رو عوض کن */
private const val START_URL = "https://gamedooz.ir/sasha/"
private const val OFFLINE_URL = "file:///android_asset/offline.html"

/** ظاهر اپ: انتخاب متن و منوی لمس طولانی مرورگر بسته می‌شه (توی فیلدهای متن فعال می‌مونه) */
private const val APP_JS = """
(function(){
  if(document.getElementById('__app'))return;
  var s=document.createElement('style');s.id='__app';
  s.textContent='*{-webkit-user-select:none;user-select:none;-webkit-touch-callout:none;-webkit-tap-highlight-color:transparent}'+
    'input,textarea,[contenteditable]{-webkit-user-select:text;user-select:text}'+
    'html,body{overscroll-behavior:none}img{-webkit-user-drag:none}';
  (document.head||document.documentElement).appendChild(s);
  document.addEventListener('contextmenu',function(e){
    var t=e.target;
    if(!(t&&t.closest&&t.closest('input,textarea,[contenteditable]')))e.preventDefault();
  },true);
  document.documentElement.classList.add('app');
})();
"""

class MainActivity : ComponentActivity() {

    private lateinit var web: WebView
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private val siteHost: String? = Uri.parse(START_URL).host
    private var ready = false   // اسپلش تا اولین صفحه‌ی کامل نشون داده می‌شه

    // انتخاب فایل (عکس پروفایل، ایموجی)
    private val picker = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val uris = WebChromeClient.FileChooserParams.parseResult(res.resultCode, res.data)
        fileCallback?.onReceiveValue(uris)
        fileCallback = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        val splash = installSplashScreen()
        super.onCreate(savedInstanceState)
        splash.setKeepOnScreenCondition { !ready }
        // اگه اینترنت کند بود، بعد از ۶ ثانیه اسپلش بره کنار
        Handler(Looper.getMainLooper()).postDelayed({ ready = true }, 6000)

        web = WebView(this).apply {
            setBackgroundColor(0xFF131B26.toInt())
            overScrollMode = View.OVER_SCROLL_NEVER
            isVerticalScrollBarEnabled = false
            isHorizontalScrollBarEnabled = false
            // لمس طولانی روی عکس و لینک منوی مرورگر نیاره (روی بقیه و فیلدها عادی کار می‌کنه)
            setOnLongClickListener {
                val t = hitTestResult.type
                t == WebView.HitTestResult.IMAGE_TYPE ||
                    t == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE ||
                    t == WebView.HitTestResult.SRC_ANCHOR_TYPE
            }
        }
        setContentView(web)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true            // localStorage: نگه داشتن ورود
            textZoom = 100                      // اندازه‌ی فونت سیستم ظاهر برنامه رو بهم نریزه
            setSupportZoom(false)
            builtInZoomControls = false
            displayZoomControls = false
            cacheMode = WebSettings.LOAD_DEFAULT
            userAgentString = userAgentString + " SashaApp/1.0"
        }

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val u = request?.url ?: return false
                if (u.scheme == "file" || u.host == siteHost) return false
                // لینک بیرونی توی مرورگر باز بشه
                runCatching { startActivity(Intent(Intent.ACTION_VIEW, u)) }
                return true
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                view?.evaluateJavascript(APP_JS, null)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                view?.evaluateJavascript(APP_JS, null)
                ready = true
            }

            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                if (request != null && request.isForMainFrame && request.url.scheme != "file") view?.loadUrl(OFFLINE_URL)
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView?, callback: ValueCallback<Array<Uri>>?, params: FileChooserParams?,
            ): Boolean {
                if (callback == null || params == null) return false
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                return try {
                    picker.launch(params.createIntent()); true
                } catch (e: Exception) {
                    fileCallback = null; false
                }
            }

            // confirm/alert وب به‌جای پنجره‌ی «این سایت می‌گوید» دیالوگ خود اپ می‌شه
            override fun onJsConfirm(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
                if (result == null) return false
                AlertDialog.Builder(this@MainActivity, R.style.Theme_Sasha_Dialog)
                    .setMessage(message)
                    .setPositiveButton("تأیید") { _, _ -> result.confirm() }
                    .setNegativeButton("انصراف") { _, _ -> result.cancel() }
                    .setOnCancelListener { result.cancel() }
                    .show()
                return true
            }

            override fun onJsAlert(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
                if (result == null) return false
                AlertDialog.Builder(this@MainActivity, R.style.Theme_Sasha_Dialog)
                    .setMessage(message)
                    .setPositiveButton("باشه") { _, _ -> result.confirm() }
                    .setOnCancelListener { result.confirm() }
                    .show()
                return true
            }
        }

        // دکمه‌ی برگشت: اول چت/صفحه‌ی داخل برنامه بسته می‌شه، بعد خروج
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val js = "(function(){var c=document.getElementById('v-chat');" +
                    "if(c&&!c.hidden){document.getElementById('ch-b').click();return 'ok'}" +
                    "var a=document.getElementById('app');" +
                    "if(a&&!a.hidden&&typeof tab!=='undefined'&&tab!=='chats'){show('chats');return 'ok'}" +
                    "return 'exit'})()"
                web.evaluateJavascript(js) { r ->
                    if (r == null || r.contains("exit")) finish()
                }
            }
        })

        val restored = savedInstanceState?.let { web.restoreState(it) }
        if (restored == null) web.loadUrl(START_URL)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    override fun onResume() { super.onResume(); web.onResume() }

    override fun onPause() {
        CookieManager.getInstance().flush()
        web.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        fileCallback?.onReceiveValue(null)
        web.destroy()
        super.onDestroy()
    }
}
