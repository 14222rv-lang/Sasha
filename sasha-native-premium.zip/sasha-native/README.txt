ساشا چت - نسخه بومی اندروید (Kotlin + Jetpack Compose)

1) Android Studio (نسخه Koala یا جدیدتر) را باز کن: File > Open > همین پوشه
2) صبر کن Gradle Sync تمام شود (بار اول اینترنت لازم است)
3) گوشی را وصل کن یا Emulator بساز و Run را بزن
4) خروجی APK: Build > Build APK(s)

آدرس سرور: app/src/main/java/ir/sasha/chat/Api.kt  (ثابت BASE)
