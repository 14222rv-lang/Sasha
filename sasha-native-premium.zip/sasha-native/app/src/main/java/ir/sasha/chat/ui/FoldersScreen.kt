package ir.sasha.chat.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.sasha.chat.*
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

/** مدیریت پوشه‌ها: ساخت، ویرایش و حذف (سقف تعداد پوشه و چت بسته به پلن) */
@Composable
fun FoldersScreen(token: String, user: User, onBack: () -> Unit, onLogout: () -> Unit) {
    var folders by remember { mutableStateOf<List<Folder>>(emptyList()) }
    var chats by remember { mutableStateOf<List<Chat>>(emptyList()) }
    var loaded by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Folder?>(null) } // id = 0 یعنی پوشه‌ی جدید
    var deleting by remember { mutableStateOf<Folder?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val lim = user.limits

    suspend fun load() {
        val f = Api.call("folders_list", token = token)
        val c = Api.call("chats_list", token = token)
        if (f.isAuthError() || c.isAuthError()) { onLogout(); return }
        if (f.optBoolean("ok")) folders = f.getJSONArray("folders").objects().map { Folder.from(it) }
        if (c.optBoolean("ok")) chats = c.getJSONArray("chats").objects().map { Chat.from(it) }
        loaded = true
    }
    LaunchedEffect(token) { load() }

    BackHandler(enabled = editing != null) { editing = null }

    val e = editing
    if (e != null) {
        FolderEditor(
            folder = e, chats = chats, maxChats = lim.folderChats,
            onCancel = { editing = null },
            onSave = { name, ids ->
                scope.launch {
                    val r = Api.call(
                        "folder_save",
                        JSONObject().put("id", e.id).put("name", name).put("chat_ids", JSONArray(ids)),
                        token,
                    )
                    if (r.optBoolean("ok")) { editing = null; error = null; load() }
                    else if (r.isAuthError()) onLogout()
                    else error = Api.errorText(r)
                }
            },
            error = error,
        )
        return
    }

    deleting?.let { f ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("حذف پوشه") },
            text = { Text("پوشه‌ی «${f.name}» حذف بشه؟ چت‌های داخلش پاک نمی‌شن.") },
            confirmButton = {
                TextButton(onClick = {
                    deleting = null
                    scope.launch {
                        val r = Api.call("folder_delete", JSONObject().put("id", f.id), token)
                        if (r.isAuthError()) onLogout() else load()
                    }
                }) { Text("حذف", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("انصراف") } },
        )
    }

    val atLimit = folders.size >= lim.folders
    Scaffold(topBar = { SashaTopBar(title = { Text("پوشه‌ها") }, onBack = onBack) }) { pad ->
        Column(Modifier.fillMaxSize().padding(pad)) {
            Column(Modifier.padding(16.dp)) {
                Button(
                    onClick = { error = null; editing = Folder(0, "", emptyList()) },
                    enabled = loaded && !atLimit, modifier = Modifier.fillMaxWidth(),
                ) {
                    AppIcon(R.drawable.ic_add, tint = androidx.compose.ui.graphics.Color.White, size = 20.dp)
                    Spacer(Modifier.width(8.dp))
                    Text("پوشه‌ی جدید")
                }
                Text(
                    "${folders.size} از ${lim.folders} پوشه" +
                        (if (atLimit && !user.premium) " — با پریمیوم تا ۲۰ پوشه" else ""),
                    fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 6.dp),
                )
            }
            HorizontalDivider(thickness = 0.5.dp)
            when {
                !loaded -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                folders.isEmpty() -> Text(
                    "هنوز پوشه‌ای نساختی.\nچت‌هات رو توی پوشه‌ها دسته‌بندی کن.",
                    Modifier.padding(32.dp), color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                else -> LazyColumn(Modifier.fillMaxSize()) {
                    items(folders, key = { it.id }) { f ->
                        Row(
                            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            AppIcon(R.drawable.ic_folder, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(f.name, fontSize = 16.sp, maxLines = 1)
                                Text("${f.chatIds.size} چت", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            TextButton(onClick = { error = null; editing = f }) { Text("ویرایش") }
                            TextButton(onClick = { deleting = f }) { Text("حذف", color = MaterialTheme.colorScheme.error) }
                        }
                        HorizontalDivider(thickness = 0.5.dp)
                    }
                }
            }
        }
    }
}

@Composable
private fun FolderEditor(
    folder: Folder,
    chats: List<Chat>,
    maxChats: Int,
    onCancel: () -> Unit,
    onSave: (String, List<Int>) -> Unit,
    error: String?,
) {
    var name by remember { mutableStateOf(folder.name) }
    var selected by remember { mutableStateOf(folder.chatIds.toSet()) }
    var hint by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            SashaTopBar(
                title = { Text(if (folder.id == 0) "پوشه‌ی جدید" else "ویرایش پوشه") },
                onBack = onCancel,
                actions = {
                    TextButton(
                        onClick = { onSave(name.trim(), selected.toList()) },
                        enabled = name.isNotBlank(),
                    ) { Text("ذخیره", color = androidx.compose.ui.graphics.Color.White) }
                },
            )
        },
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad)) {
            OutlinedTextField(
                value = name, onValueChange = { name = it.take(40) }, singleLine = true,
                label = { Text("نام پوشه") }, modifier = Modifier.fillMaxWidth().padding(16.dp),
            )
            Text(
                "${selected.size} از $maxChats چت انتخاب شده",
                fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp),
            )
            (hint ?: error)?.let {
                Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
            }
            HorizontalDivider(Modifier.padding(top = 8.dp), thickness = 0.5.dp)
            LazyColumn(Modifier.fillMaxSize()) {
                items(chats, key = { it.id }) { c ->
                    val on = c.id in selected
                    fun toggle() {
                        if (on) { selected = selected - c.id; hint = null }
                        else if (selected.size >= maxChats) hint = "حداکثر $maxChats چت توی یه پوشه جا می‌شه"
                        else { selected = selected + c.id; hint = null }
                    }
                    Row(
                        Modifier.fillMaxWidth().clickable(onClick = ::toggle).padding(horizontal = 16.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        if (c.isGroup) GroupAvatar(c.title, 40.dp) else Avatar(c.title, 40.dp, c.peer?.avatar)
                        Spacer(Modifier.width(12.dp))
                        Text(c.title, Modifier.weight(1f), fontSize = 16.sp, maxLines = 1)
                        Checkbox(checked = on, onCheckedChange = { toggle() })
                    }
                }
            }
        }
    }
}
