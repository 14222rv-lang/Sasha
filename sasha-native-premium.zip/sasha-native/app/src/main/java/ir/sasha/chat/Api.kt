package ir.sasha.chat

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

object Api {
    // آدرس سرور ساشا
    const val BASE = "https://gamedooz.ir/sasha/api.php"

    /** پایه‌ی آدرس فایل‌ها (عکس پروفایل: avatars/ID.jpg) */
    val ASSET_BASE: String = BASE.substringBeforeLast("/") + "/"

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    /** همیشه یک JSONObject برمی‌گردونه: {ok:true,...} یا {ok:false,error:"..."} */
    suspend fun call(action: String, body: JSONObject = JSONObject(), token: String? = null): JSONObject =
        withContext(Dispatchers.IO) {
            val req = Request.Builder()
                .url("$BASE?action=$action")
                .post(body.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
                .apply { if (token != null) header("X-Token", token) }
                .build()
            try {
                client.newCall(req).execute().use { res ->
                    val text = res.body?.string().orEmpty()
                    try { JSONObject(text) } catch (e: Exception) { fail("bad_response") }
                }
            } catch (e: IOException) {
                fail("network")
            }
        }

    private fun fail(code: String) = JSONObject().put("ok", false).put("error", code)

    fun errorText(r: JSONObject): String = when (r.optString("error")) {
        "bad_credentials" -> "نام کاربری یا رمز اشتباه است"
        "bad_username" -> "نام کاربری باید ۳ تا ۲۴ حرف انگلیسی کوچک، عدد یا _ باشد"
        "bad_name" -> "نام نمایشی را وارد کن"
        "bad_title" -> "اسم گروه را وارد کن"
        "weak_password" -> "رمز باید حداقل ۶ کاراکتر باشد"
        "bad_invite" -> "کد دعوت نامعتبر است یا تمام شده"
        "username_taken" -> "این نام کاربری قبلاً گرفته شده"
        "bad_image" -> "عکس معتبر نیست یا حجمش زیاد است"
        "forbidden" -> "اجازه‌ی این کار را نداری"
        "owner_cannot_leave" -> "سازنده‌ی گروه نمی‌تواند از آن خارج شود"
        "not_found" -> "پیدا نشد"
        "empty" -> "پیام خالیه"
        "premium_required" -> "این امکان فقط برای کاربران پریمیوم است"
        "restricted" -> "این کاربر گفتگوی جدید را محدود کرده است"
        "bio_too_long" -> "بیو از حد مجاز طولانی‌تر است"
        "pin_limit" -> "به سقف تعداد پین رسیدی"
        "folder_limit" -> "به سقف تعداد پوشه رسیدی"
        "folder_chats_limit" -> "تعداد چت‌های این پوشه از حد مجاز بیشتر است"
        "banned" -> "حساب شما مسدود شده است" + r.optString("reason").let { if (it.isNotBlank() && it != "null") ": $it" else "" }
        "network" -> "اتصال به سرور برقرار نشد"
        else -> "خطای ناشناخته (${r.optString("error")})"
    }
}
