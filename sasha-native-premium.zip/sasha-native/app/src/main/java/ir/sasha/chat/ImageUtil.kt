package ir.sasha.chat

import android.content.ContentResolver
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.util.Base64
import androidx.exifinterface.media.ExifInterface
import java.io.ByteArrayOutputStream

object ImageUtil {
    private fun isAnimatedType(mime: String?) = mime == "image/gif" || mime == "image/webp"

    private fun readRaw(cr: ContentResolver, uri: Uri, maxBytes: Int): ByteArray? {
        val bytes = cr.openInputStream(uri)!!.use { it.readBytes() }
        return if (bytes.size <= maxBytes) bytes else null
    }

    private fun decodeScaled(cr: ContentResolver, uri: Uri, maxSide: Int): Bitmap {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > maxSide * 2) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        var bmp = cr.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, opts) }!!
        val orientation = runCatching {
            cr.openInputStream(uri)!!.use {
                ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            }
        }.getOrDefault(ExifInterface.ORIENTATION_NORMAL)
        val deg = when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> 0f
        }
        val scale = maxSide.toFloat() / maxOf(bmp.width, bmp.height)
        val m = Matrix().apply {
            if (scale < 1f) postScale(scale, scale)
            if (deg != 0f) postRotate(deg)
        }
        bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        return bmp
    }

    /**
     * عکس پروفایل (Base64).
     * - کاربر عادی: همیشه JPEG ثابت (حتی اگه WebP/GIF انتخاب کنه، فقط فریم اول)
     * - پریمیوم: GIF/WebP متحرک بدون تغییر فرستاده می‌شه (حداکثر ۱.۵ مگابایت)
     * null یعنی خوندن ممکن نشد یا فایل متحرک خیلی بزرگه
     */
    fun prepareAvatar(cr: ContentResolver, uri: Uri, premium: Boolean = false): String? = runCatching {
        if (premium && isAnimatedType(cr.getType(uri))) {
            val raw = readRaw(cr, uri, 1_500_000) ?: return@runCatching null
            return@runCatching Base64.encodeToString(raw, Base64.NO_WRAP)
        }
        val bmp = decodeScaled(cr, uri, 512)
        var q = 85
        var bytes: ByteArray
        do {
            val out = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.JPEG, q, out)
            bytes = out.toByteArray()
            q -= 10
        } while (bytes.size > 450_000 && q > 30)
        Base64.encodeToString(bytes, Base64.NO_WRAP)
    }.getOrNull()

    /** ایموجی وضعیت: GIF/WebP تا ۴۰۰ کیلوبایت بدون تغییر، بقیه PNG حداکثر ۱۲۸ پیکسل */
    fun prepareEmoji(cr: ContentResolver, uri: Uri): String? = runCatching {
        if (isAnimatedType(cr.getType(uri))) {
            val raw = readRaw(cr, uri, 400_000) ?: return@runCatching null
            return@runCatching Base64.encodeToString(raw, Base64.NO_WRAP)
        }
        val bmp = decodeScaled(cr, uri, 128)
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
        if (out.size() > 390_000) null else Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }.getOrNull()
}
