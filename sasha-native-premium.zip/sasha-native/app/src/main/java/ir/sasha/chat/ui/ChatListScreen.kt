package ir.sasha.chat.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.sasha.chat.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONObject

@Composable
fun ChatListScreen(
    token: String,
    user: User,
    onOpen: (Chat) -> Unit,
    onNewChat: () -> Unit,
    onProfile: () -> Unit,
    onFolders: () -> Unit,
    onUserUpdated: (User) -> Unit,
    onLogout: () -> Unit,
) {
    var chats by remember { mutableStateOf<List<Chat>>(emptyList()) }
    var folders by remember { mutableStateOf<List<Folder>>(emptyList()) }
    var selectedFolder by remember { mutableIntStateOf(0) } // 0 = همه
    var loaded by remember { mutableStateOf(false) }
    var offline by remember { mutableStateOf(false) }
    val snack = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    suspend fun loadChats() {
        val r = Api.call("chats_list", token = token)
        if (r.optBoolean("ok")) {
            chats = r.getJSONArray("chats").objects().map { Chat.from(it) }
            offline = false
        } else if (r.isAuthError()) onLogout()
        else offline = true
        loaded = true
    }

    // اطلاعات کاربر (پریمیوم، عکس و ...) و پوشه‌ها رو تازه می‌کنیم
    LaunchedEffect(token) {
        val r = Api.call("me", token = token)
        if (r.optBoolean("ok")) onUserUpdated(User.from(r.getJSONObject("user")))
        else if (r.isAuthError()) onLogout()
    }
    LaunchedEffect(token) {
        val r = Api.call("folders_list", token = token)
        if (r.optBoolean("ok")) {
            folders = r.getJSONArray("folders").objects().map { Folder.from(it) }
            if (folders.none { it.id == selectedFolder }) selectedFolder = 0
        }
    }

    // لیست چت‌ها هر ۴ ثانیه به‌روز می‌شه (تا وقتی این صفحه بازه)
    LaunchedEffect(token) {
        while (true) { loadChats(); delay(4000) }
    }

    fun togglePin(chat: Chat) {
        scope.launch {
            val r = Api.call("chat_pin", JSONObject().put("chat_id", chat.id).put("pinned", !chat.pinned), token)
            if (r.optBoolean("ok")) loadChats()
            else if (r.isAuthError()) onLogout()
            else {
                val msg = if (r.optString("error") == "pin_limit")
                    "حداکثر ${user.limits.pins} چت رو می‌تونی پین کنی" + if (!user.premium) " (پریمیوم: ۱۰)" else ""
                else Api.errorText(r)
                snack.showSnackbar(msg)
            }
        }
    }

    val shown = remember(chats, folders, selectedFolder) {
        val f = folders.firstOrNull { it.id == selectedFolder }
        if (f == null) chats else chats.filter { it.id in f.chatIds }
    }

    Scaffold(
        topBar = {
            SashaTopBar(
                title = {
                    Column {
                        Text("ساشا چت")
                        if (offline) Text("در حال اتصال...", fontSize = 12.sp)
                    }
                },
                actions = {
                    if (user.premium) { PremiumBadge(20.dp); Spacer(Modifier.width(4.dp)) }
                    IconButton(onClick = onFolders) { AppIcon(R.drawable.ic_folder) }
                    IconButton(onClick = onProfile) { AppIcon(R.drawable.ic_person) }
                },
            )
        },
        snackbarHost = { SnackbarHost(snack) },
        floatingActionButton = {
            FloatingActionButton(onClick = onNewChat, containerColor = MaterialTheme.colorScheme.primary) {
                AppIcon(R.drawable.ic_add, tint = Color.White)
            }
        },
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad)) {
            if (folders.isNotEmpty()) {
                val tabIndex = if (selectedFolder == 0) 0 else folders.indexOfFirst { it.id == selectedFolder } + 1
                ScrollableTabRow(selectedTabIndex = tabIndex.coerceAtLeast(0), edgePadding = 8.dp) {
                    Tab(selected = selectedFolder == 0, onClick = { selectedFolder = 0 }, text = { Text("همه") })
                    folders.forEach { f ->
                        Tab(selected = selectedFolder == f.id, onClick = { selectedFolder = f.id }, text = { Text(f.name, maxLines = 1) })
                    }
                }
            }
            Box(Modifier.fillMaxSize()) {
                when {
                    !loaded -> CircularProgressIndicator(Modifier.align(Alignment.Center))
                    shown.isEmpty() -> Text(
                        if (chats.isEmpty()) "هنوز چتی نداری.\nبا دکمه‌ی + یه گفتگو شروع کن." else "این پوشه خالیه.",
                        Modifier.align(Alignment.Center).padding(32.dp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    else -> LazyColumn(Modifier.fillMaxSize()) {
                        items(shown, key = { it.id }) { chat ->
                            ChatRow(chat, user.id, onClick = { onOpen(chat) }, onTogglePin = { togglePin(chat) })
                            HorizontalDivider(Modifier.padding(start = 80.dp), thickness = 0.5.dp)
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ChatRow(chat: Chat, myId: Int, onClick: () -> Unit, onTogglePin: () -> Unit) {
    val preview = when {
        chat.lastBody == null -> "پیامی نیست"
        chat.lastBody.isBlank() -> "پیام حذف شد"
        chat.lastUid == myId -> "شما: ${chat.lastBody}"
        chat.isGroup && !chat.lastSender.isNullOrBlank() -> "${chat.lastSender}: ${chat.lastBody}"
        else -> chat.lastBody
    }
    var menu by remember { mutableStateOf(false) }
    Box {
        Row(
            Modifier.fillMaxWidth()
                .combinedClickable(onClick = onClick, onLongClick = { menu = true })
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (chat.isGroup) GroupAvatar(chat.title, 52.dp) else Avatar(chat.title, 52.dp, chat.peer?.avatar)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (chat.isGroup) {
                        AppIcon(R.drawable.ic_group, tint = MaterialTheme.colorScheme.onSurfaceVariant, size = 16.dp)
                        Spacer(Modifier.width(4.dp))
                    }
                    val peer = chat.peer
                    if (peer != null && !chat.isGroup) {
                        NameLine(chat.title, peer.premium, peer.nameColor, peer.emoji, weight = FontWeight.Medium, modifier = Modifier.weight(1f, fill = false))
                    } else {
                        Text(
                            chat.title, Modifier.weight(1f, fill = false), fontWeight = FontWeight.Medium, fontSize = 16.sp,
                            maxLines = 1, overflow = TextOverflow.Ellipsis,
                        )
                    }
                    Spacer(Modifier.weight(1f))
                    Text(TimeFmt.short(chat.lastAt), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Spacer(Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        preview, Modifier.weight(1f), fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    if (chat.unread > 0) {
                        Spacer(Modifier.width(8.dp))
                        Text(
                            chat.unread.toString(), color = Color.White, fontSize = 12.sp,
                            modifier = Modifier.defaultMinSize(minWidth = 22.dp).clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary).padding(horizontal = 7.dp, vertical = 2.dp),
                        )
                    } else if (chat.pinned) {
                        Spacer(Modifier.width(8.dp))
                        AppIcon(R.drawable.ic_pin, tint = MaterialTheme.colorScheme.onSurfaceVariant, size = 16.dp)
                    }
                }
            }
        }
        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
            DropdownMenuItem(
                text = { Text(if (chat.pinned) "برداشتن پین" else "پین کردن") },
                leadingIcon = { AppIcon(R.drawable.ic_pin, size = 20.dp) },
                onClick = { menu = false; onTogglePin() },
            )
        }
    }
}
