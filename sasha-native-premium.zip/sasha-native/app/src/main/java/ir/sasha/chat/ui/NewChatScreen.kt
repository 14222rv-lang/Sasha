package ir.sasha.chat.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.sasha.chat.*
import kotlinx.coroutines.launch
import org.json.JSONObject

@Composable
fun NewChatScreen(
    token: String,
    onBack: () -> Unit,
    onNewGroup: () -> Unit,
    onOpened: (Chat) -> Unit,
    onLogout: () -> Unit,
) {
    var query by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val search = rememberUserSearch(token, query, onLogout)
    val scope = rememberCoroutineScope()

    fun open(u: User) {
        scope.launch {
            val r = Api.call("chat_private", JSONObject().put("user_id", u.id), token)
            if (r.optBoolean("ok")) onOpened(Chat(r.getInt("chat_id"), "private", u.displayName, null, null, 0, null, 0, u))
            else if (r.isAuthError()) onLogout()
            else error = Api.errorText(r)
        }
    }

    Scaffold(topBar = { SashaTopBar(title = { Text("گفتگوی جدید") }, onBack = onBack) }) { pad ->
        Column(Modifier.fillMaxSize().padding(pad)) {
            Row(
                Modifier.fillMaxWidth().clickable(onClick = onNewGroup).padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                GroupAvatar("گروه", 46.dp)
                Spacer(Modifier.width(12.dp))
                Text("گروه جدید", fontSize = 16.sp, color = MaterialTheme.colorScheme.primary)
            }
            HorizontalDivider(thickness = 0.5.dp)
            OutlinedTextField(
                value = query, onValueChange = { query = it }, singleLine = true,
                placeholder = { Text("جستجوی نام یا نام کاربری") },
                leadingIcon = { AppIcon(R.drawable.ic_search, size = 20.dp) },
                modifier = Modifier.fillMaxWidth().padding(12.dp),
            )
            error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(horizontal = 16.dp)) }
            if (search.searched && search.results.isEmpty()) {
                Text("کاربری پیدا نشد", Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            LazyColumn(Modifier.fillMaxSize()) {
                items(search.results, key = { it.id }) { u -> UserRow(u, onClick = { open(u) }) }
            }
        }
    }
}
