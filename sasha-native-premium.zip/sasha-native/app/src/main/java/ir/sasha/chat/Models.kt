package ir.sasha.chat

import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

private fun JSONObject.strOrNull(k: String): String? = if (isNull(k)) null else getString(k)
fun JSONArray.objects(): List<JSONObject> = (0 until length()).map { getJSONObject(it) }
fun JSONObject.isAuthError() = optString("error") in listOf("unauthorized", "banned")

data class Chat(
    val id: Int,
    val type: String, // private | group
    val title: String,
    val lastBody: String?,
    val lastAt: String?,
    val lastUid: Int,
    val lastSender: String?,
    val unread: Int,
    val peer: User?,
    val role: String = "member",
    val pinned: Boolean = false,
) {
    val isGroup get() = type == "group"

    companion object {
        fun from(j: JSONObject) = Chat(
            id = j.getInt("id"),
            type = j.getString("type"),
            title = j.strOrNull("title") ?: "",
            lastBody = j.strOrNull("last_body"),
            lastAt = j.strOrNull("last_at"),
            lastUid = j.optInt("last_uid"),
            lastSender = j.strOrNull("last_sender"),
            unread = j.optInt("unread"),
            peer = j.optJSONObject("peer")?.let { User.from(it) },
            role = j.optString("role", "member"),
            pinned = j.optBoolean("pinned"),
        )
    }
}

data class Member(val user: User, val role: String)

data class Message(
    val id: Int,
    val userId: Int,
    val body: String,
    val createdAt: String,
    val sender: String,
    val senderPremium: Boolean = false,
    val senderColor: Int = 0,
    val senderEmoji: String? = null,
    val replyTo: Int = 0,
    val replyBody: String? = null,
    val replySender: String? = null,
    val edited: Boolean = false,
    val deleted: Boolean = false,
) {
    companion object {
        fun from(j: JSONObject) = Message(
            id = j.getInt("id"),
            userId = j.getInt("user_id"),
            body = j.getString("body"),
            createdAt = j.getString("created_at"),
            sender = j.optString("sender"),
            senderPremium = j.optBoolean("sender_premium"),
            senderColor = j.optInt("sender_color"),
            senderEmoji = j.strOrNull("sender_emoji"),
            replyTo = j.optInt("reply_to"),
            replyBody = j.strOrNull("reply_body"),
            replySender = j.strOrNull("reply_sender"),
            edited = j.optBoolean("edited"),
            deleted = j.optBoolean("deleted"),
        )
    }
}

data class Folder(val id: Int, val name: String, val chatIds: List<Int>) {
    companion object {
        fun from(j: JSONObject): Folder {
            val arr = j.optJSONArray("chat_ids")
            return Folder(
                id = j.getInt("id"),
                name = j.getString("name"),
                chatIds = if (arr == null) emptyList() else (0 until arr.length()).map { arr.getInt(it) },
            )
        }
    }
}

/** سرور همه‌ی زمان‌ها رو UTC می‌ده؛ اینجا به ساعت گوشی تبدیل می‌شه */
object TimeFmt {
    private fun parse(s: String): Date? = runCatching {
        SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }.parse(s)
    }.getOrNull()

    fun clock(s: String?): String {
        val d = s?.let(::parse) ?: return ""
        return SimpleDateFormat("HH:mm", Locale.US).format(d)
    }

    /** امروز: ساعت، قبل‌تر: ماه/روز */
    fun short(s: String?): String {
        val d = s?.let(::parse) ?: return ""
        val day = SimpleDateFormat("yyyyMMdd", Locale.US)
        return if (day.format(d) == day.format(Date())) clock(s) else SimpleDateFormat("MM/dd", Locale.US).format(d)
    }

    /** «آنلاین» یا «آخرین بازدید ...» از روی last_seen سرور (UTC) */
    fun lastSeen(s: String?): String {
        val d = s?.let(::parse) ?: return ""
        val diff = (System.currentTimeMillis() - d.time) / 1000
        if (diff < 45) return "آنلاین"
        if (diff < 3600) return "آخرین بازدید ${maxOf(1, diff / 60)} دقیقه پیش"
        val day = SimpleDateFormat("yyyyMMdd", Locale.US)
        val t = clock(s)
        return when (day.format(d)) {
            day.format(Date()) -> "آخرین بازدید امروز $t"
            day.format(Date(System.currentTimeMillis() - 86_400_000L)) -> "آخرین بازدید دیروز $t"
            else -> "آخرین بازدید ${SimpleDateFormat("MM/dd", Locale.US).format(d)}"
        }
    }
}
