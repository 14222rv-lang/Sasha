package ir.sasha.chat

import android.content.Context
import org.json.JSONObject

/** سقف‌های پلن (رایگان / پریمیوم)؛ همون عددهایی که سرور تو plan_limits می‌ده */
data class Limits(val bio: Int = 70, val pins: Int = 5, val folders: Int = 3, val folderChats: Int = 50) {
    companion object {
        private val PREMIUM = Limits(140, 10, 20, 200)

        fun from(j: JSONObject?, premium: Boolean): Limits {
            val d = if (premium) PREMIUM else Limits()
            if (j == null) return d
            return Limits(
                bio = j.optInt("bio", d.bio),
                pins = j.optInt("pins", d.pins),
                folders = j.optInt("folders", d.folders),
                folderChats = j.optInt("folder_chats", d.folderChats),
            )
        }
    }
}

data class User(
    val id: Int,
    val username: String,
    val displayName: String,
    val isAdmin: Boolean,
    val premium: Boolean,
    val premiumUntil: String?,
    val avatar: String? = null,
    val bio: String = "",
    val nameColor: Int = 0,
    val profileColor: Int = 0,
    val emoji: String? = null,
    val restrictNew: Boolean = false,
    val limits: Limits = Limits(),
) {
    fun toJson(): JSONObject = JSONObject()
        .put("id", id).put("username", username).put("display_name", displayName)
        .put("is_admin", isAdmin).put("premium", premium)
        .put("premium_until", premiumUntil ?: JSONObject.NULL)
        .put("avatar", avatar ?: JSONObject.NULL)
        .put("bio", bio).put("name_color", nameColor).put("profile_color", profileColor)
        .put("emoji", emoji ?: JSONObject.NULL)
        .put("restrict_new", restrictNew)
        .put("limits", JSONObject()
            .put("bio", limits.bio).put("pins", limits.pins)
            .put("folders", limits.folders).put("folder_chats", limits.folderChats))

    companion object {
        private fun JSONObject.optStr(k: String): String? = optString(k).takeIf { it.isNotBlank() && it != "null" }

        fun from(j: JSONObject): User {
            val premium = j.optBoolean("premium")
            return User(
                id = j.getInt("id"),
                username = j.getString("username"),
                displayName = j.getString("display_name"),
                isAdmin = j.optBoolean("is_admin"),
                premium = premium,
                premiumUntil = j.optStr("premium_until"),
                avatar = j.optStr("avatar"),
                bio = j.optString("bio", ""),
                nameColor = j.optInt("name_color"),
                profileColor = j.optInt("profile_color"),
                emoji = j.optStr("emoji"),
                restrictNew = j.optBoolean("restrict_new"),
                limits = Limits.from(j.optJSONObject("limits"), premium),
            )
        }
    }
}

/** ذخیره‌ی توکن و اطلاعات کاربر روی گوشی */
class Session(context: Context) {
    private val sp = context.getSharedPreferences("sasha", Context.MODE_PRIVATE)

    var token: String?
        get() = sp.getString("token", null)
        set(v) { sp.edit().putString("token", v).apply() }

    var user: User?
        get() = sp.getString("user", null)?.let { runCatching { User.from(JSONObject(it)) }.getOrNull() }
        set(v) { sp.edit().putString("user", v?.toJson()?.toString()).apply() }

    fun clear() { sp.edit().clear().apply() }
}
