package ir.sasha.chat

import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import coil.Coil
import coil.ImageLoader
import coil.decode.GifDecoder
import coil.decode.ImageDecoderDecoder
import ir.sasha.chat.ui.*

private val Light = lightColorScheme(primary = Color(0xFF3A8EE6), secondary = Color(0xFF527DA3))
private val Dark = darkColorScheme(
    primary = Color(0xFF5EA6F0), secondary = Color(0xFF242F3D),
    background = Color(0xFF17212B), surface = Color(0xFF17212B),
)

sealed interface Screen {
    data object Home : Screen
    data object NewChat : Screen
    data object NewGroup : Screen
    data object Profile : Screen
    data object Folders : Screen
    data class Conversation(val chat: Chat) : Screen
    data class GroupInfo(val chat: Chat) : Screen
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // پشتیبانی از GIF/WebP متحرک (آواتار و ایموجی پریمیوم)
        Coil.setImageLoader(
            ImageLoader.Builder(this).components {
                if (Build.VERSION.SDK_INT >= 28) add(ImageDecoderDecoder.Factory()) else add(GifDecoder.Factory())
            }.build()
        )
        val session = Session(applicationContext)
        setContent {
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) Dark else Light) {
                // کل اپ راست‌به‌چپ (فارسی)
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    var token by remember { mutableStateOf(session.token) }
                    var user by remember { mutableStateOf(session.user) }
                    var screen by remember { mutableStateOf<Screen>(Screen.Home) }

                    fun logout() { session.clear(); token = null; user = null; screen = Screen.Home }
                    fun updateUser(u: User) { session.user = u; user = u }

                    val t = token
                    val u = user
                    if (t == null || u == null) {
                        AuthScreen { newToken, newUser ->
                            session.token = newToken; session.user = newUser
                            token = newToken; user = newUser
                        }
                    } else {
                        BackHandler(enabled = screen !is Screen.Home) {
                            screen = when (val s = screen) {
                                is Screen.GroupInfo -> Screen.Conversation(s.chat)
                                else -> Screen.Home
                            }
                        }
                        when (val s = screen) {
                            Screen.Home -> ChatListScreen(
                                token = t, user = u,
                                onOpen = { screen = Screen.Conversation(it) },
                                onNewChat = { screen = Screen.NewChat },
                                onProfile = { screen = Screen.Profile },
                                onFolders = { screen = Screen.Folders },
                                onUserUpdated = ::updateUser,
                                onLogout = ::logout,
                            )
                            Screen.NewChat -> NewChatScreen(
                                token = t,
                                onBack = { screen = Screen.Home },
                                onNewGroup = { screen = Screen.NewGroup },
                                onOpened = { screen = Screen.Conversation(it) },
                                onLogout = ::logout,
                            )
                            Screen.NewGroup -> NewGroupScreen(
                                token = t,
                                onBack = { screen = Screen.NewChat },
                                onCreated = { screen = Screen.Conversation(it) },
                                onLogout = ::logout,
                            )
                            Screen.Profile -> ProfileScreen(
                                token = t, user = u,
                                onBack = { screen = Screen.Home },
                                onUserUpdated = ::updateUser,
                                onLogout = ::logout,
                            )
                            Screen.Folders -> FoldersScreen(
                                token = t, user = u,
                                onBack = { screen = Screen.Home },
                                onLogout = ::logout,
                            )
                            is Screen.Conversation -> ChatScreen(
                                token = t, me = u, chat = s.chat,
                                onBack = { screen = Screen.Home },
                                onInfo = { screen = Screen.GroupInfo(s.chat) },
                                onLogout = ::logout,
                            )
                            is Screen.GroupInfo -> GroupInfoScreen(
                                token = t, me = u, chat = s.chat,
                                onBack = { screen = Screen.Conversation(s.chat) },
                                onLeft = { screen = Screen.Home },
                                onLogout = ::logout,
                            )
                        }
                    }
                }
            }
        }
    }
}
