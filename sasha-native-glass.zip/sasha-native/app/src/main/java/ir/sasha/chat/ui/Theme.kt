package ir.sasha.chat.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp

// ───────── رنگ‌های برند ─────────
val BrandBlue = Color(0xFF4C8DFF)
val BrandViolet = Color(0xFF7B61FF)
val BrandGradient = Brush.linearGradient(listOf(BrandBlue, BrandViolet))

val LocalIsDark = staticCompositionLocalOf { false }

// پس‌زمینه‌ی Scaffold ها شفاف است تا گرادیان SashaBackground دیده شود
private val LightScheme = lightColorScheme(
    primary = Color(0xFF3D7FF5), onPrimary = Color.White,
    secondary = Color(0xFF4F6FD6), onSecondary = Color.White,
    background = Color.Transparent, onBackground = Color(0xFF101828),
    surface = Color(0xFFF7F9FE), onSurface = Color(0xFF101828),
    surfaceVariant = Color(0xFFE3E9F6), onSurfaceVariant = Color(0xFF667085),
    surfaceContainerLow = Color(0xFFF3F6FC), surfaceContainer = Color(0xFFF3F6FC),
    surfaceContainerHigh = Color.White, surfaceContainerHighest = Color(0xFFE9EEF9),
    outline = Color(0x33101828), outlineVariant = Color(0x1F101828),
    error = Color(0xFFE5484D),
)

private val DarkScheme = darkColorScheme(
    primary = Color(0xFF6BA6FF), onPrimary = Color(0xFF06142E),
    secondary = Color(0xFF34457F), onSecondary = Color.White,
    background = Color.Transparent, onBackground = Color(0xFFEAF0FB),
    surface = Color(0xFF111A2B), onSurface = Color(0xFFEAF0FB),
    surfaceVariant = Color(0xFF1B2640), onSurfaceVariant = Color(0xFF94A1BA),
    surfaceContainerLow = Color(0xFF111A2B), surfaceContainer = Color(0xFF141D31),
    surfaceContainerHigh = Color(0xFF1B2640), surfaceContainerHighest = Color(0xFF223052),
    outline = Color(0x33FFFFFF), outlineVariant = Color(0x1FFFFFFF),
    error = Color(0xFFFF6B70),
)

private val SashaShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp),
)

@Composable
fun SashaTheme(dark: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (dark) DarkScheme else LightScheme, shapes = SashaShapes) {
        CompositionLocalProvider(LocalIsDark provides dark) {
            SashaBackground { content() }
        }
    }
}

/** پس‌زمینه‌ی نرم: یه رنگ پایه + سه لکه‌ی گرادیان. یک بار کشیده می‌شه و سبکه. */
@Composable
fun SashaBackground(content: @Composable BoxScope.() -> Unit) {
    val dark = LocalIsDark.current
    val base = if (dark) Color(0xFF0A101C) else Color(0xFFEDF1FA)
    val c1 = if (dark) Color(0xFF3B5BDB).copy(alpha = .40f) else Color(0xFF8FB4FF).copy(alpha = .60f)
    val c2 = if (dark) Color(0xFF7048E8).copy(alpha = .32f) else Color(0xFFC9AEFF).copy(alpha = .55f)
    val c3 = if (dark) Color(0xFF14A3B8).copy(alpha = .22f) else Color(0xFFA2E8E2).copy(alpha = .50f)
    Box(
        Modifier.fillMaxSize().background(base).drawBehind {
            val w = size.width
            val h = size.height
            drawRect(Brush.radialGradient(listOf(c1, Color.Transparent), center = Offset(w * .9f, h * .05f), radius = w * .95f))
            drawRect(Brush.radialGradient(listOf(c2, Color.Transparent), center = Offset(w * .05f, h * .5f), radius = w * 1.0f))
            drawRect(Brush.radialGradient(listOf(c3, Color.Transparent), center = Offset(w * .85f, h * .98f), radius = w * .9f))
        },
        content = content,
    )
}

// ───────── شیشه ─────────

@Composable
fun glassTint(strong: Boolean = false): Color =
    if (LocalIsDark.current) Color(0xFF1A2540).copy(alpha = if (strong) .78f else .50f)
    else Color.White.copy(alpha = if (strong) .80f else .55f)

@Composable
fun glassEdge(): Brush {
    val dark = LocalIsDark.current
    val a = if (dark) .16f else .95f
    val b = if (dark) .03f else .25f
    return Brush.linearGradient(listOf(Color.White.copy(alpha = a), Color.White.copy(alpha = b)))
}

/** سطح شیشه‌ای: رنگ نیمه‌شفاف + لبه‌ی براق. strong برای نوارها و ورودی‌ها. */
@Composable
fun Modifier.glass(shape: Shape = RoundedCornerShape(22.dp), strong: Boolean = false): Modifier =
    this.clip(shape).background(glassTint(strong)).border(0.8.dp, glassEdge(), shape)

@Composable
fun GradientButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    content: @Composable RowScope.() -> Unit,
) {
    Row(
        modifier.clip(RoundedCornerShape(18.dp))
            .background(BrandGradient, alpha = if (enabled) 1f else .45f)
            .clickable(enabled = enabled, onClick = onClick),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        CompositionLocalProvider(LocalContentColor provides Color.White) { content() }
    }
}

@Composable
fun glassFieldColors(): TextFieldColors {
    val c = MaterialTheme.colorScheme
    return OutlinedTextFieldDefaults.colors(
        focusedBorderColor = c.primary,
        unfocusedBorderColor = c.onSurface.copy(alpha = .14f),
        focusedContainerColor = c.onSurface.copy(alpha = .05f),
        unfocusedContainerColor = c.onSurface.copy(alpha = .04f),
    )
}
