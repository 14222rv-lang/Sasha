package ir.sasha.chat.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.sasha.chat.*
import ir.sasha.chat.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

@Composable
fun ProfileScreen(token: String, user: User, onBack: () -> Unit, onUserUpdated: (User) -> Unit, onLogout: () -> Unit) {
    var name by remember { mutableStateOf(user.displayName) }
    var bio by remember { mutableStateOf(user.bio) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var isError by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val cr = LocalContext.current.contentResolver

    fun fail(r: JSONObject) { if (r.isAuthError()) onLogout() else { message = Api.errorText(r); isError = true } }
    fun info(t: String) { message = t; isError = false }

    suspend fun refresh() {
        val r = Api.call("me", token = token)
        if (r.optBoolean("ok")) onUserUpdated(User.from(r.getJSONObject("user"))) else fail(r)
    }

    /** یک درخواست ساده بفرست، بعدش اطلاعات رو تازه کن */
    fun action(endpoint: String, body: JSONObject, done: String? = null) {
        scope.launch {
            busy = true; message = null
            val r = Api.call(endpoint, body, token)
            if (r.optBoolean("ok")) { refresh(); done?.let(::info) } else fail(r)
            busy = false
        }
    }

    fun uploadAvatar(uri: Uri) {
        scope.launch {
            busy = true; message = null
            val data = withContext(Dispatchers.IO) { ImageUtil.prepareAvatar(cr, uri, user.premium) }
            if (data == null) { message = "خواندن عکس ممکن نشد یا حجمش زیاد است"; isError = true; busy = false; return@launch }
            val r = Api.call("profile_photo", JSONObject().put("image", data), token)
            if (r.optBoolean("ok")) { refresh(); info("عکس پروفایل عوض شد") } else fail(r)
            busy = false
        }
    }

    fun uploadEmoji(uri: Uri) {
        scope.launch {
            busy = true; message = null
            val data = withContext(Dispatchers.IO) { ImageUtil.prepareEmoji(cr, uri) }
            if (data == null) { message = "خواندن ایموجی ممکن نشد یا حجمش از ۴۰۰ کیلوبایت بیشتره"; isError = true; busy = false; return@launch }
            val r = Api.call("emoji_set", JSONObject().put("image", data), token)
            if (r.optBoolean("ok")) { refresh(); info("ایموجی وضعیت عوض شد") } else fail(r)
            busy = false
        }
    }

    val avatarPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> if (uri != null) uploadAvatar(uri) }
    val emojiPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> if (uri != null) uploadEmoji(uri) }

    val header = profileColorOf(if (user.premium) user.profileColor else 0) ?: MaterialTheme.colorScheme.secondary
    val changed = name.trim() != user.displayName || bio.trim() != user.bio

    Scaffold(topBar = { SashaTopBar(title = { Text("پروفایل") }, onBack = onBack) }) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState())) {
            // بالای صفحه با رنگ پروفایل
            Column(
                Modifier.fillMaxWidth().background(header).padding(top = 20.dp, bottom = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Box(Modifier.size(120.dp).clickable(enabled = !busy) { avatarPicker.launch("image/*") }) {
                    Avatar(user.displayName, 120.dp, user.avatar)
                    Box(
                        Modifier.align(Alignment.BottomEnd).size(38.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary),
                        contentAlignment = Alignment.Center,
                    ) {
                        if (busy) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp, color = Color.White)
                        else AppIcon(R.drawable.ic_camera, tint = Color.White, size = 20.dp)
                    }
                }
                Spacer(Modifier.height(10.dp))
                CompositionLocalProvider(LocalContentColor provides Color.White) {
                    NameLine(
                        user.displayName, user.premium, user.nameColor, user.emoji,
                        fontSize = 20.sp, weight = FontWeight.Bold, onDarkBar = true, badge = 18.dp,
                        modifier = Modifier.padding(horizontal = 24.dp),
                    )
                }
                if (user.bio.isNotBlank()) {
                    Text(user.bio, color = Color.White.copy(alpha = .85f), fontSize = 13.sp, modifier = Modifier.padding(horizontal = 24.dp, vertical = 2.dp))
                }
                if (user.avatar != null) {
                    TextButton(
                        onClick = { action("profile_photo", JSONObject().put("remove", true)) },
                        enabled = !busy,
                        colors = ButtonDefaults.textButtonColors(contentColor = Color.White),
                    ) { Text("حذف عکس") }
                }
            }

            Column(Modifier.padding(20.dp)) {
                OutlinedTextField(
                    value = name, onValueChange = { name = it.take(60) }, singleLine = true,
                    label = { Text("نام نمایشی") }, modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = bio, onValueChange = { bio = it.take(user.limits.bio) },
                    label = { Text("بیو") }, modifier = Modifier.fillMaxWidth(), maxLines = 3,
                    supportingText = { Text("${bio.length} از ${user.limits.bio}" + if (!user.premium) " (پریمیوم: ۱۴۰)" else "") },
                )
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = {
                        action(
                            "profile_update",
                            JSONObject().put("display_name", name.trim()).put("bio", bio.trim()),
                            "ذخیره شد",
                        )
                    },
                    enabled = !busy && name.isNotBlank() && changed,
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("ذخیره") }

                message?.let {
                    Spacer(Modifier.height(8.dp))
                    Text(it, color = if (isError) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
                }

                Spacer(Modifier.height(24.dp))
                HorizontalDivider(thickness = 0.5.dp)
                InfoRow("نام کاربری", "@${user.username}")
                Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("پریمیوم", fontSize = 15.sp, modifier = Modifier.weight(1f))
                    if (user.premium) {
                        PremiumBadge(18.dp)
                        Spacer(Modifier.width(6.dp))
                        Text("فعال تا ${user.premiumUntil?.take(10) ?: ""}", fontSize = 14.sp)
                    } else {
                        Text("غیرفعال", fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                if (user.isAdmin) InfoRow("نقش", "ادمین")
                HorizontalDivider(thickness = 0.5.dp)

                Spacer(Modifier.height(16.dp))
                PremiumSection(
                    user = user, busy = busy,
                    onNameColor = { action("profile_colors", JSONObject().put("name_color", it).put("profile_color", user.profileColor)) },
                    onProfileColor = { action("profile_colors", JSONObject().put("name_color", user.nameColor).put("profile_color", it)) },
                    onPickEmoji = { emojiPicker.launch("image/*") },
                    onRemoveEmoji = { action("emoji_set", JSONObject().put("remove", true)) },
                    onRestrict = { action("privacy_set", JSONObject().put("restrict_new", it)) },
                )

                Spacer(Modifier.height(24.dp))
                OutlinedButton(
                    onClick = onLogout, modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                ) {
                    AppIcon(R.drawable.ic_logout, size = 20.dp)
                    Spacer(Modifier.width(8.dp))
                    Text("خروج از حساب")
                }
            }
        }
    }
}

@Composable
private fun PremiumSection(
    user: User,
    busy: Boolean,
    onNameColor: (Int) -> Unit,
    onProfileColor: (Int) -> Unit,
    onPickEmoji: () -> Unit,
    onRemoveEmoji: () -> Unit,
    onRestrict: (Boolean) -> Unit,
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        PremiumBadge(18.dp)
        Spacer(Modifier.width(6.dp))
        Text("امکانات پریمیوم", fontSize = 16.sp, fontWeight = FontWeight.Bold)
    }
    Spacer(Modifier.height(8.dp))

    if (!user.premium) {
        Text(
            "با پریمیوم این امکانات باز می‌شن:\n" +
                "• رنگ دلخواه برای نام و صفحه‌ی پروفایل\n" +
                "• ایموجی وضعیت کنار نام\n" +
                "• عکس پروفایل متحرک (GIF و WebP)\n" +
                "• بیوی بلندتر (۱۴۰ حرف)، تا ۱۰ پین و ۲۰ پوشه\n" +
                "• محدود کردن گفتگوی جدید از طرف غریبه‌ها\n\n" +
                "برای فعال‌سازی با ادمین تماس بگیر.",
            fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, lineHeight = 22.sp,
        )
        return
    }

    Text("رنگ نام", fontSize = 14.sp, modifier = Modifier.padding(vertical = 6.dp))
    ColorPicker(selected = user.nameColor, enabled = !busy, onDark = false, onPick = onNameColor)

    Text("رنگ پروفایل", fontSize = 14.sp, modifier = Modifier.padding(top = 14.dp, bottom = 6.dp))
    ColorPicker(selected = user.profileColor, enabled = !busy, onDark = false, onPick = onProfileColor, profile = true)

    Text("ایموجی وضعیت", fontSize = 14.sp, modifier = Modifier.padding(top = 14.dp, bottom = 6.dp))
    Row(verticalAlignment = Alignment.CenterVertically) {
        if (user.emoji != null) { EmojiImage(user.emoji, 36.dp); Spacer(Modifier.width(12.dp)) }
        OutlinedButton(onClick = onPickEmoji, enabled = !busy) { Text(if (user.emoji == null) "انتخاب تصویر" else "تغییر") }
        if (user.emoji != null) {
            Spacer(Modifier.width(8.dp))
            TextButton(onClick = onRemoveEmoji, enabled = !busy) { Text("حذف") }
        }
    }
    Text(
        "PNG، JPG یا GIF/WebP متحرک، حداکثر ۴۰۰ کیلوبایت",
        fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 4.dp),
    )

    Spacer(Modifier.height(14.dp))
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("محدود کردن گفتگوی جدید", fontSize = 15.sp)
            Text(
                "فقط کسایی که قبلاً با هم چت داشتید می‌تونن پیام بدن",
                fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Switch(checked = user.restrictNew, onCheckedChange = onRestrict, enabled = !busy)
    }
}

/** ردیف رنگ‌ها: اولی «پیش‌فرض» و بعدش ۳۰ رنگ */
@Composable
private fun ColorPicker(selected: Int, enabled: Boolean, onDark: Boolean, onPick: (Int) -> Unit, profile: Boolean = false) {
    val scroll = rememberScrollState()
    Row(Modifier.horizontalScroll(scroll), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        for (i in 0..COLOR_COUNT) {
            val c = if (profile) profileColorOf(i) else nameColorOf(i, onDark)
            val sel = i == selected
            Box(
                Modifier.size(34.dp).clip(CircleShape)
                    .background(c ?: MaterialTheme.colorScheme.surfaceVariant)
                    .border(if (sel) BorderStroke(3.dp, MaterialTheme.colorScheme.primary) else BorderStroke(0.dp, Color.Transparent), CircleShape)
                    .clickable(enabled = enabled) { onPick(i) },
                contentAlignment = Alignment.Center,
            ) {
                if (i == 0) Text("∅", fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                else if (sel) AppIcon(R.drawable.ic_check, tint = Color.White, size = 18.dp)
            }
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 12.dp)) {
        Text(label, fontSize = 15.sp, modifier = Modifier.weight(1f))
        Text(value, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
