package ir.sasha.chat.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.sasha.chat.Api
import ir.sasha.chat.User
import kotlinx.coroutines.launch
import org.json.JSONObject

@Composable
fun AuthScreen(onDone: (token: String, user: User) -> Unit) {
    var register by remember { mutableStateOf(false) }
    var username by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var invite by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    fun submit() {
        if (loading) return
        scope.launch {
            loading = true; error = null
            val body = JSONObject().put("username", username.trim()).put("password", password)
            if (register) body.put("display_name", name.trim()).put("invite", invite.trim())
            val r = Api.call(if (register) "register" else "login", body)
            loading = false
            if (r.optBoolean("ok")) onDone(r.getString("token"), User.from(r.getJSONObject("user")))
            else error = Api.errorText(r)
        }
    }

    Surface(Modifier.fillMaxSize(), color = Color.Transparent) {
        Column(
            Modifier.fillMaxSize().safeDrawingPadding().verticalScroll(rememberScrollState()).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Text("ساشا چت", style = TextStyle(brush = BrandGradient, fontSize = 36.sp, fontWeight = FontWeight.ExtraBold))
            Spacer(Modifier.height(4.dp))
            Text(
                if (register) "ساخت حساب جدید" else "ورود به حساب",
                fontSize = 15.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(28.dp))

            Column(
                Modifier.fillMaxWidth().glass(RoundedCornerShape(28.dp), strong = true).padding(20.dp),
            ) {
                val fieldShape = RoundedCornerShape(16.dp)
                OutlinedTextField(
                    value = username, onValueChange = { username = it.lowercase().filter { c -> !c.isWhitespace() } },
                    label = { Text("نام کاربری") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                    shape = fieldShape, colors = glassFieldColors(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii),
                )
                if (register) {
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        value = name, onValueChange = { name = it },
                        label = { Text("نام نمایشی") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                        shape = fieldShape, colors = glassFieldColors(),
                    )
                }
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = password, onValueChange = { password = it },
                    label = { Text("رمز عبور") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                    shape = fieldShape, colors = glassFieldColors(),
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                )
                if (register) {
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        value = invite, onValueChange = { invite = it.uppercase() },
                        label = { Text("کد دعوت") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                        shape = fieldShape, colors = glassFieldColors(),
                    )
                }

                error?.let {
                    Spacer(Modifier.height(12.dp))
                    Text(it, color = MaterialTheme.colorScheme.error)
                }

                Spacer(Modifier.height(20.dp))
                GradientButton(onClick = ::submit, enabled = !loading, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                    if (loading) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp, color = Color.White)
                    else Text(if (register) "ثبت‌نام" else "ورود", fontWeight = FontWeight.Bold)
                }
            }
            TextButton(onClick = { register = !register; error = null }) {
                Text(if (register) "حساب دارم، ورود" else "حساب ندارم، ثبت‌نام")
            }
        }
    }
}
