package ir.sasha.chat.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.sasha.chat.*
import ir.sasha.chat.R
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONObject

@Composable
fun ChatScreen(token: String, me: User, chat: Chat, onBack: () -> Unit, onInfo: () -> Unit, onLogout: () -> Unit) {
    var messages by remember { mutableStateOf<List<Message>>(emptyList()) }
    var peerRead by remember { mutableIntStateOf(0) }
    var peerSeen by remember { mutableStateOf<String?>(null) }
    var since by remember { mutableStateOf<String?>(null) }
    var text by remember { mutableStateOf("") }
    var sending by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var loaded by remember { mutableStateOf(false) }
    var replyTo by remember { mutableStateOf<Message?>(null) }
    var editing by remember { mutableStateOf<Message?>(null) }
    var confirmDelete by remember { mutableStateOf<Message?>(null) }
    var searching by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<Message>>(emptyList()) }
    var prevSize by remember { mutableIntStateOf(0) }
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    val dark = isSystemInDarkTheme()
    val clipboard = LocalClipboardManager.current
    val focus = remember { FocusRequester() }
    val isAdmin = chat.isGroup && chat.role in listOf("owner", "admin")

    suspend fun fetch() {
        val after = messages.lastOrNull()?.id ?: 0
        val body = JSONObject().put("chat_id", chat.id).put("after_id", after)
        since?.let { body.put("since", it) }
        val r = Api.call("messages_get", body, token)
        if (r.optBoolean("ok")) {
            val fresh = r.getJSONArray("messages").objects().map { Message.from(it) }
            val last = messages.lastOrNull()?.id ?: 0
            val add = fresh.filter { it.id > last }
            val changed = r.optJSONArray("changed")?.objects()?.map { Message.from(it) }.orEmpty()
            if (add.isNotEmpty() || changed.isNotEmpty()) {
                val byId = changed.associateBy { it.id }
                messages = messages.map { byId[it.id] ?: it } + add
            }
            r.optString("now").takeIf { it.isNotBlank() }?.let { since = it }
            peerRead = r.optInt("peer_read")
            peerSeen = if (r.isNull("peer_seen")) null else r.optString("peer_seen")
            loaded = true
        } else if (r.isAuthError()) onLogout()
    }

    /** ۵۰ پیام قدیمی‌تر رو بالای لیست اضافه می‌کنه؛ false یعنی چیزی نمونده */
    suspend fun loadOlder(): Boolean {
        val first = messages.firstOrNull()?.id ?: return false
        val r = Api.call("messages_get", JSONObject().put("chat_id", chat.id).put("before_id", first), token)
        if (!r.optBoolean("ok")) return false
        val older = r.getJSONArray("messages").objects().map { Message.from(it) }.filter { it.id < first }
        if (older.isEmpty()) return false
        messages = older + messages
        prevSize = messages.size
        return true
    }

    // پیام‌های جدید (و ویرایش/حذف‌ها) هر ۲.۵ ثانیه
    LaunchedEffect(chat.id) {
        while (true) { fetch(); delay(2500) }
    }

    // اسکرول به آخرین پیام: بار اول، پیام خودم، یا وقتی کاربر پایین لیست بوده
    val lastId = messages.lastOrNull()?.id ?: 0
    LaunchedEffect(lastId) {
        val n = messages.size
        if (n > 0) {
            val lastVisible = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: -1
            if (prevSize == 0 || lastVisible >= prevSize - 2 || messages.last().userId == me.id) listState.scrollToItem(n - 1)
        }
        prevSize = n
    }

    // جستجو با کمی تاخیر بعد از تایپ
    LaunchedEffect(query, searching) {
        if (!searching || query.isBlank()) { results = emptyList(); return@LaunchedEffect }
        delay(300)
        val r = Api.call("messages_search", JSONObject().put("chat_id", chat.id).put("q", query.trim()), token)
        if (r.optBoolean("ok")) results = r.getJSONArray("messages").objects().map { Message.from(it) }
        else if (r.isAuthError()) onLogout()
    }
    LaunchedEffect(searching) { if (searching) runCatching { focus.requestFocus() } }

    fun closeSearch() { searching = false; query = ""; results = emptyList() }

    /** پرش به یه پیام؛ اگه بالاتر از پیام‌های بارگذاری‌شده بود، قدیمی‌ترها رو هم می‌آره */
    fun jumpTo(id: Int) {
        scope.launch {
            var tries = 0
            while (messages.none { it.id == id } && tries < 10 && loadOlder()) tries++
            val idx = messages.indexOfFirst { it.id == id }
            delay(50)
            if (idx >= 0) listState.scrollToItem(idx) else error = "این پیام خیلی قدیمیه و پیدا نشد"
        }
    }

    fun send() {
        val body = text.trim().take(4000)
        if (body.isEmpty() || sending) return
        val ed = editing
        val rp = replyTo
        sending = true; error = null; text = ""
        scope.launch {
            val r = if (ed != null) {
                Api.call("message_edit", JSONObject().put("message_id", ed.id).put("body", body), token)
            } else {
                val req = JSONObject().put("chat_id", chat.id).put("body", body)
                if (rp != null) req.put("reply_to", rp.id)
                Api.call("message_send", req, token)
            }
            sending = false
            if (r.optBoolean("ok")) { editing = null; replyTo = null; fetch() }
            else if (r.isAuthError()) onLogout()
            else { text = body; error = Api.errorText(r) }
        }
    }

    BackHandler(enabled = searching || replyTo != null || editing != null) {
        when {
            searching -> closeSearch()
            editing != null -> { editing = null; text = "" }
            else -> replyTo = null
        }
    }

    confirmDelete?.let { m ->
        AlertDialog(
            onDismissRequest = { confirmDelete = null },
            title = { Text("حذف پیام") },
            text = { Text("این پیام برای همه حذف می‌شه.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = null
                    scope.launch {
                        val r = Api.call("message_delete", JSONObject().put("message_id", m.id), token)
                        if (r.optBoolean("ok")) fetch()
                        else if (r.isAuthError()) onLogout()
                        else error = Api.errorText(r)
                    }
                }) { Text("حذف", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = null }) { Text("انصراف") } },
        )
    }

    Scaffold(
        containerColor = Color.Transparent,
        contentWindowInsets = WindowInsets(0),
        topBar = {
            if (searching) {
                SashaTopBar(
                    onBack = ::closeSearch,
                    title = {
                        TextField(
                            value = query, onValueChange = { query = it }, singleLine = true,
                            placeholder = { Text("جستجو توی پیام‌ها", color = MaterialTheme.colorScheme.onSurfaceVariant) },
                            modifier = Modifier.fillMaxWidth().focusRequester(focus),
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                                focusedTextColor = MaterialTheme.colorScheme.onSurface, unfocusedTextColor = MaterialTheme.colorScheme.onSurface,
                                cursorColor = MaterialTheme.colorScheme.primary,
                                focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                            ),
                        )
                    },
                )
            } else {
                SashaTopBar(
                    onBack = onBack,
                    title = {
                        Row(
                            Modifier.then(if (chat.isGroup) Modifier.clickable(onClick = onInfo) else Modifier),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            if (chat.isGroup) GroupAvatar(chat.title, 36.dp) else Avatar(chat.title, 36.dp, chat.peer?.avatar)
                            Spacer(Modifier.width(10.dp))
                            Column {
                                val peer = chat.peer
                                NameLine(
                                    chat.title, peer?.premium == true, peer?.nameColor ?: 0, peer?.emoji,
                                    fontSize = 17.sp, weight = FontWeight.Bold,
                                )
                                Text(
                                    when {
                                        chat.isGroup -> "گروه"
                                        peerSeen != null -> TimeFmt.lastSeen(peerSeen)
                                        else -> "@${chat.peer?.username ?: ""}"
                                    },
                                    fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                    },
                    actions = { IconButton(onClick = { searching = true }) { AppIcon(R.drawable.ic_search) } },
                )
            }
        },
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).imePadding().navigationBarsPadding()) {
            Box(Modifier.weight(1f).fillMaxWidth()) {
                if (searching) {
                    when {
                        query.isBlank() -> Text("کلمه‌ای که دنبالشی رو بنویس", Modifier.align(Alignment.Center).padding(24.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                        results.isEmpty() -> Text("پیامی پیدا نشد", Modifier.align(Alignment.Center).padding(24.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                        else -> LazyColumn(Modifier.fillMaxSize().background(glassTint(strong = true))) {
                            items(results, key = { it.id }) { m ->
                                Column(
                                    Modifier.fillMaxWidth().clickable { closeSearch(); jumpTo(m.id) }.padding(horizontal = 16.dp, vertical = 10.dp),
                                ) {
                                    Row {
                                        Text(m.sender, fontWeight = FontWeight.Medium, fontSize = 14.sp, modifier = Modifier.weight(1f))
                                        Text(TimeFmt.short(m.createdAt), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    Text(m.body, fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                HorizontalDivider(thickness = 0.5.dp)
                            }
                        }
                    }
                } else {
                    if (!loaded) CircularProgressIndicator(Modifier.align(Alignment.Center))
                    else if (messages.isEmpty()) Text(
                        "هنوز پیامی نیست. اولین پیام رو بفرست.",
                        Modifier.align(Alignment.Center).padding(24.dp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    LazyColumn(Modifier.fillMaxSize(), state = listState, contentPadding = PaddingValues(vertical = 10.dp)) {
                        items(messages, key = { it.id }) { m ->
                            Bubble(
                                m, mine = m.userId == me.id, showSender = chat.isGroup, read = peerRead >= m.id, dark = dark,
                                canDelete = m.userId == me.id || isAdmin,
                                onReply = { editing = null; replyTo = m },
                                onEdit = { replyTo = null; editing = m; text = m.body },
                                onDelete = { confirmDelete = m },
                                onCopy = { clipboard.setText(AnnotatedString(m.body)) },
                                onJumpReply = { jumpTo(m.replyTo) },
                            )
                        }
                    }
                }
            }
            error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)) }

            val ctx = editing ?: replyTo
            if (ctx != null && !searching) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 10.dp).glass(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp, bottomStart = 6.dp, bottomEnd = 6.dp), strong = true)
                        .padding(start = 12.dp, end = 4.dp, top = 6.dp, bottom = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(Modifier.width(3.dp).height(34.dp).clip(RoundedCornerShape(2.dp)).background(BrandGradient))
                    Spacer(Modifier.width(8.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            if (editing != null) "ویرایش پیام" else "پاسخ به ${ctx.sender}",
                            fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, maxLines = 1,
                        )
                        Text(ctx.body, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    IconButton(onClick = { replyTo = null; if (editing != null) { editing = null; text = "" } }) {
                        AppIcon(R.drawable.ic_close, size = 20.dp)
                    }
                }
            }
            if (!searching) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.Bottom,
                ) {
                    TextField(
                        value = text, onValueChange = { text = it },
                        modifier = Modifier.weight(1f).glass(RoundedCornerShape(26.dp), strong = true),
                        placeholder = { Text("پیام...", color = MaterialTheme.colorScheme.onSurfaceVariant) },
                        maxLines = 5,
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                            disabledContainerColor = Color.Transparent,
                            focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                            disabledIndicatorColor = Color.Transparent,
                            cursorColor = MaterialTheme.colorScheme.primary,
                        ),
                    )
                    Spacer(Modifier.width(8.dp))
                    val canSend = text.isNotBlank() && !sending
                    Box(
                        Modifier.size(52.dp).clip(CircleShape)
                            .background(BrandGradient, CircleShape, alpha = if (canSend) 1f else .4f)
                            .clickable(enabled = canSend, onClick = ::send),
                        contentAlignment = Alignment.Center,
                    ) { AppIcon(if (editing != null) R.drawable.ic_check else R.drawable.ic_send, tint = Color.White) }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun Bubble(
    m: Message,
    mine: Boolean,
    showSender: Boolean,
    read: Boolean,
    dark: Boolean,
    canDelete: Boolean,
    onReply: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onCopy: () -> Unit,
    onJumpReply: () -> Unit,
) {
    val fg = if (mine) Color.White else MaterialTheme.colorScheme.onSurface
    val soft = if (mine) Color.White.copy(alpha = .72f) else fg.copy(alpha = .55f)
    val accent = if (mine) Color.White else MaterialTheme.colorScheme.primary
    val shape = if (mine) RoundedCornerShape(20.dp, 20.dp, 6.dp, 20.dp) else RoundedCornerShape(20.dp, 20.dp, 20.dp, 6.dp)
    val bubbleMod = if (mine) Modifier.clip(shape).background(BrandGradient) else Modifier.glass(shape)
    var menu by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 2.dp),
        horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start,
    ) {
        Box {
            Column(
                Modifier.widthIn(max = 300.dp).then(bubbleMod)
                    .combinedClickable(onClick = {}, onLongClick = { if (!m.deleted) menu = true })
                    .padding(horizontal = 12.dp, vertical = 7.dp),
            ) {
                if (!mine && showSender) {
                    if (m.senderPremium) NameLine(m.sender, true, m.senderColor, m.senderEmoji, fontSize = 12.sp, weight = FontWeight.Bold, badge = 12.dp)
                    else Text(m.sender, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                }
                if (m.replyTo > 0 && !m.deleted) {
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 3.dp).clip(RoundedCornerShape(6.dp))
                            .background(accent.copy(alpha = if (mine) .20f else .12f))
                            .clickable(onClick = onJumpReply)
                            .height(IntrinsicSize.Min),
                    ) {
                        Box(Modifier.width(3.dp).fillMaxHeight().background(accent))
                        Column(Modifier.padding(horizontal = 8.dp, vertical = 4.dp)) {
                            Text(m.replySender.orEmpty(), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = accent, maxLines = 1)
                            Text(m.replyBody ?: "پیام حذف شد", fontSize = 12.sp, color = soft, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
                if (m.deleted) Text("این پیام حذف شد", color = soft, fontSize = 14.sp, fontStyle = FontStyle.Italic)
                else Text(m.body, color = fg, fontSize = 15.sp, lineHeight = 22.sp)
                Row(Modifier.align(Alignment.End), verticalAlignment = Alignment.CenterVertically) {
                    if (m.edited && !m.deleted) Text("ویرایش شده  ", fontSize = 11.sp, color = soft)
                    Text(TimeFmt.clock(m.createdAt), fontSize = 11.sp, color = soft)
                    if (mine && !m.deleted) {
                        Spacer(Modifier.width(4.dp))
                        if (read) AppIcon(R.drawable.ic_done_all, tint = if (mine) Color.White else MaterialTheme.colorScheme.primary, size = 15.dp)
                        else AppIcon(R.drawable.ic_check, tint = soft, size = 15.dp)
                    }
                }
            }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(text = { Text("پاسخ") }, onClick = { menu = false; onReply() })
                DropdownMenuItem(text = { Text("کپی") }, onClick = { menu = false; onCopy() })
                if (mine) DropdownMenuItem(text = { Text("ویرایش") }, onClick = { menu = false; onEdit() })
                if (canDelete) DropdownMenuItem(
                    text = { Text("حذف", color = MaterialTheme.colorScheme.error) },
                    onClick = { menu = false; onDelete() },
                )
            }
        }
    }
}
