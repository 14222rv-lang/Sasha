package ir.sasha.chat.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.clickable
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.sasha.chat.*
import ir.sasha.chat.R
import kotlinx.coroutines.launch
import org.json.JSONObject

@Composable
fun GroupInfoScreen(token: String, me: User, chat: Chat, onBack: () -> Unit, onLeft: () -> Unit, onLogout: () -> Unit) {
    var members by remember { mutableStateOf<List<Member>>(emptyList()) }
    var loaded by remember { mutableStateOf(false) }
    var adding by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var confirmRemove by remember { mutableStateOf<Member?>(null) }
    var confirmLeave by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    suspend fun load() {
        val r = Api.call("group_members", JSONObject().put("chat_id", chat.id), token)
        if (r.optBoolean("ok")) {
            members = r.getJSONArray("members").objects().map { Member(User.from(it), it.optString("role", "member")) }
            loaded = true
        } else if (r.isAuthError()) onLogout()
        else error = Api.errorText(r)
    }
    LaunchedEffect(chat.id) { load() }

    BackHandler(adding) { adding = false }

    val myRole = members.firstOrNull { it.user.id == me.id }?.role ?: chat.role
    val isStaff = myRole == "owner" || myRole == "admin"

    fun act(action: String, body: JSONObject, after: suspend () -> Unit = { load() }) {
        scope.launch {
            error = null
            val r = Api.call(action, body.put("chat_id", chat.id), token)
            if (r.optBoolean("ok")) after() else if (r.isAuthError()) onLogout() else error = Api.errorText(r)
        }
    }

    fun canRemove(m: Member) =
        m.role != "owner" && m.user.id != me.id && (myRole == "owner" || (myRole == "admin" && m.role == "member"))

    Scaffold(
        containerColor = Color.Transparent,
        topBar = {
            SashaTopBar(
                title = { Text(if (adding) "افزودن عضو" else "اطلاعات گروه") },
                onBack = { if (adding) adding = false else onBack() },
            )
        },
    ) { pad ->
        SashaGlassBackground(Modifier.fillMaxSize().padding(pad)) {
        Box(Modifier.fillMaxSize()) {
            if (adding) {
                AddMemberPane(token, existing = members.map { it.user.id }.toSet(), onLogout = onLogout) { u ->
                    act("group_add", JSONObject().put("user_id", u.id)) { load(); adding = false }
                }
            } else if (!loaded) {
                CircularProgressIndicator(Modifier.align(Alignment.Center))
            } else {
                LazyColumn(Modifier.fillMaxSize()) {
                    item {
                        GlassPanel(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 14.dp)) {
                            Column(Modifier.fillMaxWidth().padding(vertical = 22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                GroupAvatar(chat.title, 90.dp)
                                Spacer(Modifier.height(12.dp))
                                Text(chat.title, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                                Text("${members.size} عضو", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                    if (isStaff) item {
                        Row(
                            Modifier.fillMaxWidth().clickable { adding = true }.padding(horizontal = 16.dp, vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            AppIcon(R.drawable.ic_add, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(16.dp))
                            Text("افزودن عضو", color = MaterialTheme.colorScheme.primary, fontSize = 16.sp)
                        }
                    }
                    items(members, key = { it.user.id }) { m ->
                        GlassPanel(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)) {
                        UserRow(
                            m.user,
                            subtitle = when (m.role) { "owner" -> "مالک"; "admin" -> "ادمین"; else -> "@${m.user.username}" },
                            trailing = {
                                if (myRole == "owner" && m.role != "owner") {
                                    TextButton(onClick = {
                                        act("group_set_role", JSONObject().put("user_id", m.user.id).put("role", if (m.role == "admin") "member" else "admin"))
                                    }) { Text(if (m.role == "admin") "عزل ادمین" else "ادمین کن", fontSize = 12.sp) }
                                }
                                if (canRemove(m)) IconButton(onClick = { confirmRemove = m }) {
                                    AppIcon(R.drawable.ic_close, tint = MaterialTheme.colorScheme.error, size = 20.dp)
                                }
                            },
                        )
                        }
                    }
                    item {
                        error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(16.dp)) }
                        if (myRole == "owner") {
                            Text(
                                "تو سازنده‌ی گروه هستی و نمی‌تونی ازش خارج بشی.",
                                Modifier.padding(16.dp), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        } else {
                            OutlinedButton(
                                onClick = { confirmLeave = true }, modifier = Modifier.fillMaxWidth().padding(16.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                            ) {
                                AppIcon(R.drawable.ic_logout, size = 20.dp)
                                Spacer(Modifier.width(8.dp))
                                Text("خروج از گروه")
                            }
                        }
                    }
                }
            }
        }
    }
    }

    confirmRemove?.let { m ->
        AlertDialog(
            onDismissRequest = { confirmRemove = null },
            title = { Text("حذف عضو") },
            text = { Text("${m.user.displayName} از گروه حذف بشه؟") },
            confirmButton = {
                TextButton(onClick = { confirmRemove = null; act("group_remove", JSONObject().put("user_id", m.user.id)) }) { Text("حذف") }
            },
            dismissButton = { TextButton(onClick = { confirmRemove = null }) { Text("انصراف") } },
        )
    }
    if (confirmLeave) {
        AlertDialog(
            onDismissRequest = { confirmLeave = false },
            title = { Text("خروج از گروه") },
            text = { Text("از گروه «${chat.title}» خارج بشی؟") },
            confirmButton = {
                TextButton(onClick = { confirmLeave = false; act("group_remove", JSONObject().put("user_id", me.id)) { onLeft() } }) { Text("خروج") }
            },
            dismissButton = { TextButton(onClick = { confirmLeave = false }) { Text("انصراف") } },
        )
    }
}

@Composable
private fun AddMemberPane(token: String, existing: Set<Int>, onLogout: () -> Unit, onPick: (User) -> Unit) {
    var query by remember { mutableStateOf("") }
    val search = rememberUserSearch(token, query, onLogout)
    val list = search.results.filter { it.id !in existing }
    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = query, onValueChange = { query = it }, singleLine = true,
            placeholder = { Text("جستجوی نام یا نام کاربری") },
            leadingIcon = { AppIcon(R.drawable.ic_search, size = 20.dp) },
            modifier = Modifier.fillMaxWidth().padding(12.dp),
        )
        if (search.searched && list.isEmpty()) {
            Text("کاربری پیدا نشد", Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        LazyColumn(Modifier.fillMaxSize()) {
            items(list, key = { it.id }) { u -> UserRow(u, onClick = { onPick(u) }) }
        }
        }
    }
