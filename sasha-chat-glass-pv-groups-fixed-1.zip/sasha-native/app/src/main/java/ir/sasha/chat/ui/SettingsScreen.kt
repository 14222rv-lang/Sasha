package ir.sasha.chat.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ir.sasha.chat.User
import ir.sasha.chat.R

/** صفحه تنظیمات با مسیرهای واقعی موجود در نسخه فعلی برنامه */
@Composable
fun SettingsScreen(
    user: User,
    onBack: () -> Unit,
    onProfile: () -> Unit,
    onFolders: () -> Unit,
    onChats: () -> Unit,
    onContacts: () -> Unit,
    onLogout: () -> Unit,
) {
    Scaffold(containerColor = Color.Transparent, topBar = { SashaTopBar(title = { Text("تنظیمات") }, onBack = onBack) }, bottomBar = { SashaBottomBar(selected = "settings", onChats = onChats, onContacts = onContacts, onSettings = {}, onProfile = onProfile) }) { pad ->
        SashaGlassBackground(Modifier.fillMaxSize().padding(pad)) {
            Column(
                Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 18.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                GlassPanel(Modifier.fillMaxWidth()) {
                    Row(
                        Modifier.fillMaxWidth().clickable(onClick = onProfile).padding(18.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Avatar(user.displayName, 64.dp, user.avatar)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            NameLine(user.displayName, user.premium, user.nameColor, user.emoji, fontSize = 18.sp, weight = FontWeight.Bold)
                            Text("@${user.username}", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                        }
                        AppIcon(R.drawable.ic_person, tint = MaterialTheme.colorScheme.primary)
                    }
                }

                GlassPanel(Modifier.fillMaxWidth()) {
                    Text("حساب کاربری", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 4.dp))
                    SettingsRow("پروفایل و اطلاعات حساب", "نام، بیو، عکس و امکانات پریمیوم", R.drawable.ic_person, onProfile)
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = .25f), modifier = Modifier.padding(horizontal = 16.dp))
                    SettingsRow("پوشه‌های گفتگو", "ساخت و مدیریت پوشه‌ها", R.drawable.ic_folder, onFolders)
                }

                GlassPanel(Modifier.fillMaxWidth()) {
                    Text("درباره حساب", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 8.dp))
                    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("وضعیت اشتراک", Modifier.weight(1f), fontSize = 15.sp)
                        Text(if (user.premium) "پریمیوم" else "عادی", color = if (user.premium) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.SemiBold)
                    }
                    if (user.isAdmin) {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("دسترسی", Modifier.weight(1f), fontSize = 15.sp)
                            Text("مدیر", color = MaterialTheme.colorScheme.primary)
                        }
                    }
                }

                OutlinedButton(
                    onClick = onLogout,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                ) {
                    AppIcon(R.drawable.ic_logout, tint = MaterialTheme.colorScheme.error)
                    Spacer(Modifier.width(8.dp))
                    Text("خروج از حساب")
                }
            }
        }
    }
}

@Composable
private fun SettingsRow(title: String, subtitle: String, icon: Int, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        AppIcon(icon, tint = MaterialTheme.colorScheme.primary, size = 25.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            Text(subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Text("‹", fontSize = 25.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
