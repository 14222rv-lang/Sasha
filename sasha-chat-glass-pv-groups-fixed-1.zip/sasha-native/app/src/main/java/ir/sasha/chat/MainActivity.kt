package ir.sasha.chat

import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import coil.Coil
import coil.ImageLoader
import coil.decode.GifDecoder
import coil.decode.ImageDecoderDecoder
import ir.sasha.chat.ui.*

private val Light = lightColorScheme(
    primary = Color(0xFF397FD5), onPrimary = Color.White,
    secondary = Color(0xFF537FAE), onSecondary = Color.White,
    background = Color(0xFFF2F6FC), onBackground = Color(0xFF17263A),
    surface = Color(0xFFF8FAFE), onSurface = Color(0xFF17263A),
    surfaceVariant = Color(0xFFE8EFF8), onSurfaceVariant = Color(0xFF64748B),
    outline = Color(0xFFD5E0EF),
)
private val Dark = darkColorScheme(
    primary = Color(0xFF69B7FF), onPrimary = Color(0xFF082849),
    secondary = Color(0xFF304B68), onSecondary = Color(0xFFEAF3FF),
    background = Color(0xFF0B1420), onBackground = Color(0xFFEAF2FC),
    surface = Color(0xCC1A2A3D), onSurface = Color(0xFFEAF2FC),
    surfaceVariant = Color(0xFF20364E), onSurfaceVariant = Color(0xFFB1C1D5),
    outline = Color(0xFF38516B),
)

sealed interface Screen {
    data object Home : Screen
    data object NewChat : Screen
    data object NewGroup : Screen
    data object Profile : Screen
    data object Settings : Screen
    data object Folders : Screen
    data class Conversation(val chat: Chat) : Screen
    data class GroupInfo(val chat: Chat) : Screen
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // پشتیبانی از GIF/WebP متحرک (آواتار و ایموجی پریمیوم)
        Coil.setImageLoader(
            ImageLoader.Builder(this).components {
                if (Build.VERSION.SDK_INT >= 28) add(ImageDecoderDecoder.Factory()) else add(GifDecoder.Factory())
            }.build()
        )
        val session = Session(applicationContext)
        setContent {
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) Dark else Light) {
                // کل اپ راست‌به‌چپ (فارسی)
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    var token by remember { mutableStateOf(session.token) }
                    var user by remember { mutableStateOf(session.user) }
                    var screen by remember { mutableStateOf<Screen>(Screen.Home) }

                    fun logout() { session.clear(); token = null; user = null; screen = Screen.Home }
                    fun updateUser(u: User) { session.user = u; user = u }

                    val t = token
                    val u = user
                    if (t == null || u == null) {
                        AuthScreen { newToken, newUser ->
                            session.token = newToken; session.user = newUser
                            token = newToken; user = newUser
                        }
                    } else {
                        BackHandler(enabled = screen !is Screen.Home) {
                            screen = when (val s = screen) {
                                is Screen.GroupInfo -> Screen.Conversation(s.chat)
                                else -> Screen.Home
                            }
                        }
                        when (val s = screen) {
                            Screen.Home -> ChatListScreen(
                                token = t, user = u,
                                onOpen = { screen = Screen.Conversation(it) },
                                onNewChat = { screen = Screen.NewChat },
                                onContacts = { screen = Screen.NewChat },
                                onProfile = { screen = Screen.Profile },
                                onSettings = { screen = Screen.Settings },
                                onFolders = { screen = Screen.Folders },
                                onUserUpdated = ::updateUser,
                                onLogout = ::logout,
                            )
                            Screen.NewChat -> NewChatScreen(
                                token = t,
                                onBack = { screen = Screen.Home },
                                onNewGroup = { screen = Screen.NewGroup },
                                onOpened = { screen = Screen.Conversation(it) },
                                onChats = { screen = Screen.Home },
                                onSettings = { screen = Screen.Settings },
                                onProfile = { screen = Screen.Profile },
                                onLogout = ::logout,
                            )
                            Screen.NewGroup -> NewGroupScreen(
                                token = t,
                                onBack = { screen = Screen.NewChat },
                                onCreated = { screen = Screen.Conversation(it) },
                                onLogout = ::logout,
                            )
                            Screen.Profile -> ProfileScreen(
                                token = t, user = u,
                                onBack = { screen = Screen.Home },
                                onUserUpdated = ::updateUser,
                                onChats = { screen = Screen.Home },
                                onContacts = { screen = Screen.NewChat },
                                onSettings = { screen = Screen.Settings },
                                onLogout = ::logout,
                            )
                            Screen.Settings -> SettingsScreen(
                                user = u,
                                onBack = { screen = Screen.Home },
                                onProfile = { screen = Screen.Profile },
                                onFolders = { screen = Screen.Folders },
                                onChats = { screen = Screen.Home },
                                onContacts = { screen = Screen.NewChat },
                                onLogout = ::logout,
                            )
                            Screen.Folders -> FoldersScreen(
                                token = t, user = u,
                                onBack = { screen = Screen.Home },
                                onLogout = ::logout,
                            )
                            is Screen.Conversation -> ChatScreen(
                                token = t, me = u, chat = s.chat,
                                onBack = { screen = Screen.Home },
                                onInfo = { screen = Screen.GroupInfo(s.chat) },
                                onLogout = ::logout,
                            )
                            is Screen.GroupInfo -> GroupInfoScreen(
                                token = t, me = u, chat = s.chat,
                                onBack = { screen = Screen.Conversation(s.chat) },
                                onLeft = { screen = Screen.Home },
                                onLogout = ::logout,
                            )
                        }
                    }
                }
            }
        }
    }
}
