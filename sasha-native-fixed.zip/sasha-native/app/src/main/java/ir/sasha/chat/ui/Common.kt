package ir.sasha.chat.ui

import androidx.annotation.DrawableRes
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import ir.sasha.chat.*
import ir.sasha.chat.R
import kotlinx.coroutines.delay
import org.json.JSONObject

val Gold = Color(0xFFF5A623)

private val avatarColors = listOf(0xFFE17076, 0xFFFAA774, 0xFFA695E7, 0xFF7BC862, 0xFF6EC9CB, 0xFF65AADD, 0xFFEE7AAE)

@Composable
fun AppIcon(@DrawableRes id: Int, modifier: Modifier = Modifier, tint: Color = LocalContentColor.current, size: Dp = 24.dp) {
    Icon(painterResource(id), contentDescription = null, modifier = modifier.size(size), tint = tint)
}

@Composable
fun PremiumBadge(size: Dp = 16.dp) = AppIcon(R.drawable.ic_star, tint = Gold, size = size)


/** تعداد رنگ‌های پریمیوم (۱ تا ۳۰)؛ ۰ یعنی رنگ پیش‌فرض */
const val COLOR_COUNT = 30

/** رنگ نام پریمیوم؛ روی پس‌زمینه‌ی تیره روشن‌تر می‌شه تا خونا بمونه */
fun nameColorOf(index: Int, onDark: Boolean): Color? {
    if (index <= 0) return null
    val hue = ((index - 1) * 12f) % 360f
    return if (onDark) Color.hsv(hue, 0.5f, 1f) else Color.hsv(hue, 0.85f, 0.7f)
}

/** رنگ پروفایل پریمیوم (پس‌زمینه‌ی بالای صفحه‌ی پروفایل) */
fun profileColorOf(index: Int): Color? {
    if (index <= 0) return null
    return Color.hsv(((index - 1) * 12f) % 360f, 0.6f, 0.6f)
}

/** ایموجی وضعیت پریمیوم (تصویر خود کاربر، می‌تونه متحرک باشه) */
@Composable
fun EmojiImage(url: String, size: Dp = 18.dp) {
    AsyncImage(
        model = Api.ASSET_BASE + url, contentDescription = null, contentScale = ContentScale.Fit,
        modifier = Modifier.size(size),
    )
}

/** اسم کاربر + رنگ و ایموجی و ستاره‌ی پریمیوم (فقط اگه پریمیوم باشه) */
@Composable
fun NameLine(
    name: String,
    premium: Boolean,
    colorIndex: Int = 0,
    emoji: String? = null,
    fontSize: TextUnit = 16.sp,
    weight: FontWeight? = null,
    onDarkBar: Boolean = false,
    badge: Dp = 14.dp,
    modifier: Modifier = Modifier,
) {
    val color = if (premium) nameColorOf(colorIndex, onDarkBar || isSystemInDarkTheme()) else null
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        Text(
            name, fontSize = fontSize, fontWeight = weight, maxLines = 1, overflow = TextOverflow.Ellipsis,
            color = color ?: Color.Unspecified, modifier = Modifier.weight(1f, fill = false),
        )
        if (premium) {
            if (emoji != null) { Spacer(Modifier.width(4.dp)); EmojiImage(emoji, badge + 4.dp) }
            Spacer(Modifier.width(4.dp)); PremiumBadge(badge)
        }
    }
}

/** عکس پروفایل؛ اگه نبود دایره‌ی رنگی با حرف اول اسم */
@Composable
fun Avatar(name: String, size: Dp, url: String? = null) {
    val c = Color(avatarColors[(name.hashCode() and 0x7fffffff) % avatarColors.size])
    Box(Modifier.size(size).clip(CircleShape).background(c), contentAlignment = Alignment.Center) {
        Text(name.trim().take(1).uppercase(), color = Color.White, fontSize = (size.value * 0.42f).sp, fontWeight = FontWeight.Bold)
        if (url != null) {
            AsyncImage(
                model = Api.ASSET_BASE + url, contentDescription = null, contentScale = ContentScale.Crop,
                modifier = Modifier.size(size).clip(CircleShape),
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SashaTopBar(
    title: @Composable () -> Unit,
    onBack: (() -> Unit)? = null,
    actions: @Composable RowScope.() -> Unit = {},
) {
    TopAppBar(
        title = title,
        navigationIcon = {
            if (onBack != null) IconButton(onClick = onBack) { AppIcon(R.drawable.ic_back) }
        },
        actions = actions,
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = MaterialTheme.colorScheme.secondary,
            titleContentColor = Color.White,
            navigationIconContentColor = Color.White,
            actionIconContentColor = Color.White,
        ),
    )
}

class SearchState(val results: List<User>, val searched: Boolean)

/** جستجوی کاربر با کمی تاخیر بعد از تایپ */
@Composable
fun rememberUserSearch(token: String, query: String, onLogout: () -> Unit): SearchState {
    var results by remember { mutableStateOf<List<User>>(emptyList()) }
    var searched by remember { mutableStateOf(false) }
    LaunchedEffect(query) {
        if (query.isBlank()) { results = emptyList(); searched = false; return@LaunchedEffect }
        delay(300)
        val r = Api.call("users_search", JSONObject().put("q", query.trim()), token)
        if (r.optBoolean("ok")) { results = r.getJSONArray("users").objects().map { User.from(it) }; searched = true }
        else if (r.isAuthError()) onLogout()
    }
    return SearchState(results, searched)
}

@Composable
fun UserRow(u: User, subtitle: String? = null, onClick: (() -> Unit)? = null, trailing: @Composable RowScope.() -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth()
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Avatar(u.displayName, 46.dp, u.avatar)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            NameLine(u.displayName, u.premium, u.nameColor, u.emoji)
            Text(subtitle ?: "@${u.username}", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        trailing()
    }
}

@Composable
fun GroupAvatar(name: String, size: Dp) {
    val c = Color(avatarColors[(name.hashCode() and 0x7fffffff) % avatarColors.size])
    Box(Modifier.size(size).clip(CircleShape).background(c), contentAlignment = Alignment.Center) {
        AppIcon(R.drawable.ic_group, tint = Color.White, size = size * 0.55f)
    }
}
