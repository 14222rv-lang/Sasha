package ir.sasha.chat.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import ir.sasha.chat.*
import ir.sasha.chat.R
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewGroupScreen(token: String, onBack: () -> Unit, onCreated: (Chat) -> Unit, onLogout: () -> Unit) {
    var title by remember { mutableStateOf("") }
    var query by remember { mutableStateOf("") }
    val selected = remember { mutableStateListOf<User>() }
    var creating by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val search = rememberUserSearch(token, query, onLogout)
    val scope = rememberCoroutineScope()

    fun create() {
        val t = title.trim()
        if (t.isEmpty() || creating) return
        scope.launch {
            creating = true; error = null
            val body = JSONObject().put("title", t).put("members", JSONArray(selected.map { it.id }))
            val r = Api.call("group_create", body, token)
            creating = false
            if (r.optBoolean("ok")) onCreated(Chat(r.getInt("chat_id"), "group", t, null, null, 0, null, 0, null, "owner"))
            else if (r.isAuthError()) onLogout()
            else error = Api.errorText(r)
        }
    }

    Scaffold(
        topBar = {
            SashaTopBar(
                title = { Text("گروه جدید") }, onBack = onBack,
                actions = {
                    TextButton(
                        onClick = ::create, enabled = title.isNotBlank() && !creating,
                        colors = ButtonDefaults.textButtonColors(contentColor = Color.White, disabledContentColor = Color.White.copy(alpha = .5f)),
                    ) { Text("ساخت") }
                },
            )
        },
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad)) {
            OutlinedTextField(
                value = title, onValueChange = { title = it.take(80) }, singleLine = true,
                label = { Text("اسم گروه") }, modifier = Modifier.fillMaxWidth().padding(12.dp),
            )
            if (selected.isNotEmpty()) {
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    selected.toList().forEach { u ->
                        AssistChip(
                            onClick = { selected.remove(u) },
                            label = { Text(u.displayName) },
                            trailingIcon = { AppIcon(R.drawable.ic_close, size = 16.dp) },
                        )
                    }
                }
            }
            OutlinedTextField(
                value = query, onValueChange = { query = it }, singleLine = true,
                placeholder = { Text("افزودن عضو: جستجوی نام یا نام کاربری") },
                leadingIcon = { AppIcon(R.drawable.ic_search, size = 20.dp) },
                modifier = Modifier.fillMaxWidth().padding(12.dp),
            )
            error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(horizontal = 16.dp)) }
            LazyColumn(Modifier.fillMaxSize()) {
                items(search.results, key = { it.id }) { u ->
                    val isSel = selected.any { it.id == u.id }
                    UserRow(
                        u,
                        onClick = { if (isSel) selected.removeAll { it.id == u.id } else selected.add(u) },
                        trailing = {
                            if (isSel) Box(
                                Modifier.size(24.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary),
                                contentAlignment = Alignment.Center,
                            ) { AppIcon(R.drawable.ic_check, tint = Color.White, size = 16.dp) }
                        },
                    )
                }
            }
        }
    }
}
